<?php
/*
Quên mật khẩu -> Hiển thị Form nhập EMAIL để gởi lại Mật khẩu mới -> nhập EMAIL và xác nhận xem email có tồn tại không? -> Nếu có thì gởi mail mật khẩu mới + hiển thị thông báo Đã gởi EMAIL xác nhận rồi, vui lòng check

Sau khi người dùng bấm nút Xác nhận Reset mật khẩu trong EMAIL mới -> Hiển thị lại trang FORM Reset Password để nhập mật khẩu mới. Nếu người dùng không nhập mật khẩu mới sẽ tắt chức năng....

Cần kiểm tra chức năng RESET Password này, không phải ai biết đường link cũng có thể truy cập được. (bảo mật)
*/