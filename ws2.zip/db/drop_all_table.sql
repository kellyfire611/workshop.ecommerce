-- Dumping database structure for u883604362_php
USE `u883604362_php`;

-- DROP ALL TABLES
SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE `chudegopy`;
DROP TABLE `dondathang`;
DROP TABLE `gopy`;
DROP TABLE `hinhsanpham`;
DROP TABLE `hinhthucthanhtoan`;
DROP TABLE `khachhang`;
DROP TABLE `khuyenmai`;
DROP TABLE `loaisanpham`;
DROP TABLE `nhasanxuat`;
DROP TABLE `sanpham`;
DROP TABLE `sanpham_dondathang`;
SET FOREIGN_KEY_CHECKS = 1;
